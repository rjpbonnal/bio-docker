
// common structs

#ifndef __COMMON_STRUCTS__
#define __COMMON_STRUCTS__


struct coordset {
  int lend;
  int rend;
};

#endif
