#ifndef __stringFuncts__
#define __stringFuncts__

#include <vector>
#include <string>
using namespace std;

int stringToInt (string);
float strintToFloat (string);

vector<string> stringSplitter (string s, string delimeter);






#endif
