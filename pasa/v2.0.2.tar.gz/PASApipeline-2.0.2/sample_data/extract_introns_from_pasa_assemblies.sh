#!/bin/sh

../misc/intron_extraction/pasa_asmbl_intron_extractor.pl sample_mydb_pasa.pasa_assemblies_described.txt genome_sample.fasta

