../misc_utilities/index_gff3_files_by_isoform.pl orig_annotations_sample.gff3
../misc_utilities/inx_to_introns.pl orig_annotations_sample.gff3.inx genome_sample.fasta
