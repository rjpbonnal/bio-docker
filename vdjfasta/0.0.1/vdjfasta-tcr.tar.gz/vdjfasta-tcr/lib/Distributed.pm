package Distributed;
use strict;

# Author:  Jacob Glanville 
# Contact: jacob <dot> glanville <at> pfizer <dot> com
#

# Constructor ----------------------------------------------
sub new {
  my ($class,$type) = @_;
  my $self = {};
  $type = $type || 'Xgrid';
  die "Unrecognized type: $type\n" unless $type =~ /^Xgrid|SGE$/;
  $self->{maxwait}      = 10000;   # max wait in seconds
  $self->{jobids}       =    [];
  $self->{type}         = $type;
  bless $self,'Distributed';
  return $self;
}

# Methods --------------------------------------------------

sub launchJob {
  my ($self,@args) = @_;
  if ($self->{type} eq 'Xgrid') {
    $self->launchXgridJob(@args);
  }
  elsif ($self->{type} eq 'SGE') {
    $self->launchSgeJob(@args);
  }
  else {
    die "Unrecognized scheduler type ".$self->{type}."\n";
  }
}

sub launchXgridJob {
  my($self,$filename,$scriptname,$cmd)=@_;
  # make an xgrid script
  my $current_dir=$self->getCWD();
  open(SCRIPT,">$scriptname") or die ("Error: cannot open $scriptname for writing\n");
  print SCRIPT "#!/bin/bash\n";
  print SCRIPT "sleep 1\n";
  print SCRIPT "ls /Volumes/ClusterData1/tools/apps/454/bin\n";
  print SCRIPT "sleep 1\n";
  print SCRIPT "cp $current_dir/$filename . &&\n";
  print SCRIPT "sleep 3 &&\n";
  print SCRIPT "$cmd\n";
  print SCRIPT "sleep 3\n";
  print SCRIPT "cp * $current_dir/ && \n";
  print SCRIPT "sleep 3\n";
  close(SCRIPT);
  `chmod a+x $scriptname`;
  my @results=`xgrid -h ssf-bbci-clsp01 -p password -job submit $scriptname\n`;
  # launch that script
  push @{$self->{jobids}},$self->getXgridJobID(@results);
  return $self->getXgridJobID(@results);
}

sub launchSgeJob {
  my($self,$filename,$scriptname,$cmd)=@_;
  # make an sge script
  my $current_dir=$self->getCWD();
  my $sge_dir = $current_dir.'/sge';
  if (! -e $sge_dir) {
    mkdir($sge_dir,0777) || die "Failed in attempt to create $sge_dir\n";
  }
  open(SCRIPT,">$scriptname") or die ("Error: cannot open $scriptname for writing\n");
  print SCRIPT "#!/bin/bash\n";
  print SCRIPT "#\$ -cwd\n";
  print SCRIPT "#\$ -S /bin/bash\n";
  print SCRIPT "#\$ -V\n";
  print SCRIPT "#\$ -o $sge_dir/\$HOSTNAME_\$JOB_NAME_\$JOB_ID.out\n";
  print SCRIPT "#\$ -e $sge_dir/\$HOSTNAME_\$JOB_NAME_\$JOB_ID.err\n";
  print SCRIPT "$cmd\n";
  close(SCRIPT);
  `chmod a+x $scriptname`;
  # launch that script
  my $qsubCmd = "qsub $scriptname";
  my @results=`$qsubCmd 2>&1`;
  if ($?) {
      my $exitStatus = $? >> 8;
      die "Failed in attempt to submit job with exit status $exitStatus: @results\n";
  }
  push @{$self->{jobids}},$self->getJobID(@results);
  return $self->getJobID(@results);
}

sub monitorJobs {
  my($self)=@_;
  my $isStillRunning=1;
  my $wait=0;
  while($isStillRunning){
    my $doneYet=$self->areAllJobsComplete();
    if($doneYet){
      $isStillRunning=0;
    }else{
      $wait+=300;
      sleep(300);
      if($wait>$self->{maxwait}){
        `echo "ERROR: jobs not finished after $wait seconds" >> ERROR.JOB.FAIL.txt`;
        exit;
      }
    }
  }
}

sub isJobComplete {
  my ($self,@args) = @_;
  if ($self->{type} eq 'Xgrid') {
    $self->isXgridJobComplete(@args);
  }
  elsif ($self->{type} eq 'SGE') {
    $self->isSgeJobComplete(@args);
  }
  else {
    die "Unrecognized scheduler type ".$self->{type}."\n";
  }
}

sub isXgridJobComplete {
  my($self, $id)=@_;
  my @status=`xgrid -h ssf-bbci-clsp01 -p password -job attributes -id $id | grep jobStatus`;
  chomp(@status);
  my $doneYet=1;
  if(defined($status[0])){
    if(($status[0] =~ m/Running/)||($status[0] =~ m/Pending/)){
      $doneYet=0;
    }
  }
  return $doneYet;
}

sub isSgeJobComplete {
  my($self, $id)=@_;
  my @status=`qstat 2>&1`;
  if ($?) {
    my $exitStatus = $? >> 8;
    die "Failed in attempt to execute qstat with exit status $exitStatus: @status\n";
  }
  my $doneYet=1;
  chomp(@status);
  for (my $lineNum=2; $lineNum < @status; $lineNum++) {
    $status[$lineNum] =~ s/^\s+//;
    $status[$lineNum] =~ s/\s+$//;
    my ($jobId,$priority,$name,$user,$state,@info) = split /\s+/,$status[$lineNum],-1;
    if ($jobId eq $id) {
      $doneYet = 0;
      last;
    }
  }
  return $doneYet;
}

sub areAllJobsComplete {
  my($self)=@_;
  my $alldone=1;
  for(my $x=0;$x<scalar(@{$self->{jobids}});$x++){
    unless($self->isJobComplete(${$self->{jobids}}[$x])){
	$alldone = 0;
    }
  }
  return $alldone;
}

sub getJobID {
  my ($self,@args) = @_;
  if ($self->{type} eq 'Xgrid') {
    $self->getXgridJobID(@args);
  }
  elsif ($self->{type} eq 'SGE') {
    $self->getSgeJobID(@args);
  }
  else {
    die "Unrecognized scheduler type ".$self->{type}."\n";
  }
}

sub getXgridJobID {
  my($self,@results)=@_;
  chomp(@results);
  my $jobid=0;
  for(my $x=0;$x<scalar(@results);$x++){
    if($results[$x]=~m/jobIdentifier/){
      $jobid=$results[$x];
      $jobid=~s/..* = *//;
      $jobid=~s/;//;
      return $jobid;
    }
  }
}

sub getSgeJobID {
  my($self,@results)=@_;
  chomp(@results);
  my ($jobid) = $results[0] =~ /^Your job (\d+) \([^\)]+\) has been submitted$/;
  die "Failed in attempt to parse job id from $results[0]\n" unless (defined $jobid && $jobid);
  return $jobid;
}

sub mkWorkDir {
  my($self,$rundir)=@_;
 `mkdir $rundir`;
 `chmod a+w $rundir`;
 return $rundir;
}

sub getCWD {
 my($self)=@_;
 my $current_dir=`pwd`;
 `chmod a+w .`;
 chomp($current_dir);
 return $current_dir;
}

1;
