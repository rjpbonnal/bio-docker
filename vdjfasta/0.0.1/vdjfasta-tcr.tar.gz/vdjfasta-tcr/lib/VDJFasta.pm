package VDJFasta;
use strict;
use vars qw($rootdir);
no warnings 'recursion';

# Author:  Jacob Glanville
#
# Glanville J, Zhai W, Berka J et al. Precise determination of the diversity 
# of a combinatorial antibody library gives insight into the human immunoglobulin 
# repertoire. Proc Natl Acad Sci USA. 2009;106:20216–20221

BEGIN {
  use File::Basename;
  use Cwd 'abs_path';
  $rootdir = dirname(dirname(abs_path($0)));
};

# Constructor ----------------------------------------------
sub new {
  my ($class) = @_;
  my $self = {};
  $self->{filename}     = "";
  $self->{headers}      = [];
  $self->{sequence}     = [];
  $self->{germline}     = [];
  $self->{nseqs}        =  0;

  $self->{accVsegQstart}  = {}; # example: 124
  $self->{accVsegQend}    = {}; # example: 417
  $self->{accJsegQstart}  = {};
  $self->{accJsegQend}    = {};
  $self->{accDsegQstart}  = {};
  $self->{accDsegQend}    = {};
  $self->{accCsegQstart}  = {};
  $self->{accCsegQend}    = {};

  $self->{ranVseg}        =  0; # boolean
  $self->{ranDseg}        =  0;
  $self->{ranJseg}        =  0;
  $self->{ranCseg}        =  0;

  $self->{Vseg}           = {}; # example: IGHV1-46 293 3
  $self->{Dseg}           = {};
  $self->{Jseg}           = {};
  $self->{Cseg}           = {};

  $self->{dnahanokinedb}= "$rootdir/db/imgt.phenotype.himc.cleanv1.fa"; #hanokines.fa";
  $self->{dnaVsegdb}    = "$rootdir/db/imgt.phenotype.himc.cleanv1.fa"; #imgt.V.TCR.dna.nr.fa"; #imgt.VDJ.dna.nr.fa";
  $self->{dnaJsegdb}    = "$rootdir/db/imgt.J.dna.fa";
  $self->{dnaDsegdb}    = "$rootdir/db/imgt.HD.dna.nr.fa";
  $self->{dnaCsegdb}    = "$rootdir/db/imgt.CH1.dna.nr.fa";

  $self->{VhVkHMM}      = "$rootdir/db/Vh-linker-Vk.hmm";
  $self->{TCRVhVkHMM}   = "$rootdir/db/tcrb_gs_tcra.hmm"; #"$rootdir/db/tcr-bd-gs-ag.hmm"; #$rootdir/db/tcrb_gs_tcra.hmm";

  $self->{blast}        = "blastn";
  $self->{hmmsearch}    = "hmmsearch";
  $self->{hmmalign}     = "hmmalign";

  $self->{verbose}      = 0;

  bless $self,'VDJFasta';
  return $self;
}

# Methods --------------------------------------------------

sub getGermlines {
  my($self,$domain,$outfile,$sequence_type,$custom_reference_db)=@_;
  my $blast_type="blastn";
  if($sequence_type ne "dna"){
    # $blast_type="tblastn";
    print "This functionality is not yet active. Go away.\n";
    exit; 
  }
  my $reference_db="";
  my $evalue="";
  if($domain eq "V"){
    $reference_db=$self->{dnaVsegdb};
    $evalue=10e-10;
  }elsif($domain eq "J"){
    $reference_db=$self->{dnaJsegdb};
    $evalue=0.001;
  }elsif($domain eq "D"){
    $reference_db=$self->{dnaDsegdb};
    $evalue=0.01;
  }elsif($domain eq "C"){
    $reference_db=$self->{dnaCsegdb};
    $evalue=0.001;
  }else{
    print " (V J D C)\n";
    exit;
  }
  if(defined($custom_reference_db)){
    if(-f $custom_reference_db){
      $reference_db=$custom_reference_db;
    }elsif($custom_reference_db eq "hanokines"){
      $reference_db=$self->{dnahanokinedb};
    }
  }

  if($domain eq "D"){
    $self->batchBlastParseDsegClassifier($reference_db,$evalue,$outfile,$blast_type,$domain);
  }else{  
    $self->batchBlastParseClassifier($reference_db,$evalue,$outfile,$blast_type,$domain);
  }
}

sub batchBlastParseClassifier {
  my($self,$db,$e,$outfile,$blast_type,$domain)=@_;
  my @lines=$self->getBlastLines($self->{filename},$db,$e,$blast_type);

  my %accessions=();
  my %acc_tophit=();

  for(my $x=0;$x<scalar(@lines);$x++){
    my($acc,$match,$pid,$alnlength,$mismatch,$gaps,$qstart,$qend,$mstart,$mend,$eval,$bit)=split(/\t/,$lines[$x]);
    my $hitname=$self->parse_hitname($match);

    if(!(defined($acc_tophit{$acc}))){    
      $acc_tophit{$acc} = $hitname;
      my $prob = 1;
      $accessions{$acc} = $hitname . " " . $alnlength . " " . $mismatch . " ";
      if($domain eq "V"){
        ${$self->{accVsegQstart}}{$acc}  = $qstart;
        ${$self->{accVsegQend}}{$acc}    = $qend;
      }elsif($domain eq "J"){
        ${$self->{accJsegQstart}}{$acc}  = $qstart;
        ${$self->{accJsegQend}}{$acc}    = $qend;
      }elsif($domain eq "C"){
        ${$self->{accCsegQstart}}{$acc}  = $qstart;
        ${$self->{accCsegQend}}{$acc}    = $qend;
      }
    }elsif($acc_tophit{$acc} ne $hitname){
      my $prob = 1;
      if(defined($accessions{$acc})){
        my($best_match,$best_alnlength,$best_mismatch)=split(/ /,$accessions{$acc});
        $prob = $self->miscall_probability($best_alnlength,$alnlength,$best_mismatch,$mismatch);
        $prob = (int(1000 * $prob))/1000;
      }
      if($prob > 0.01){
        $accessions{$acc} .= $hitname . " " . $alnlength . " " . $mismatch . " ";
      }
    }
  }

  my @keys=keys %accessions;
  open(OUT,">$outfile");
  for(my $k=0;$k<scalar(@keys);$k++){
    print OUT $keys[$k] . "\t" . $accessions{$keys[$k]} . "\n";
    ${$self->{$domain . "seg"}}{$keys[$k]}=$accessions{$keys[$k]};
  }
  print OUT "WRITEDONEFLAG" . "\t" . "\n";
  close(OUT);
  $self->{"ran" . $domain . "seg"}=1;
}

sub writeDsegCoords {
  my($self,$outfile)=@_;
  my @accs= keys %{$self->{accDsegQstart}};

  open(OUTFILE,">$outfile");
  for(my $a=0;$a<scalar(@accs);$a++){
    print OUTFILE  $accs[$a] . "\t"
          . ${$self->{accVsegQstart}}{$accs[$a]} . " "
          . ${$self->{accVsegQend}}{$accs[$a]} . " "
          . ${$self->{accDsegQstart}}{$accs[$a]} . " "
          . ${$self->{accDsegQend}}{$accs[$a]} . " "
          . ${$self->{accJsegQstart}}{$accs[$a]} . " "
          . ${$self->{accJsegQend}}{$accs[$a]} . "\n";
  }
  close(OUTFILE);
}

sub isDsegSandwiched {
  my($self,$acc,$dseg_qstart,$dseg_qend)=@_;

  my $answer=1;

  # if not defined, then exit
  unless(defined(${$self->{accVsegQstart}}{$acc}) && defined(${$self->{accVsegQend}}{$acc})
         && ${$self->{accJsegQstart}}{$acc} && ${$self->{accJsegQend}}{$acc} ){
    return 0;
  }

  # 1. get middle of each segment
  my $v_average= (${$self->{accVsegQstart}}{$acc} + ${$self->{accVsegQend}}{$acc}) /2;
  my $j_average= (${$self->{accJsegQstart}}{$acc} + ${$self->{accJsegQend}}{$acc}) /2;
  my $d_average= ($dseg_qstart + $dseg_qend) / 2;
  
  # 2. determine orientation
  my $orientation="forward";
  my $vseg_3prime=${$self->{accVsegQend}}{$acc};
  my $jseg_5prime=${$self->{accJsegQstart}}{$acc};
  if( $v_average > $j_average ){
    $orientation="reverse";
    $vseg_3prime=${$self->{accVsegQstart}}{$acc};
    $jseg_5prime=${$self->{accJsegQend}}{$acc};
  }

  # get lower
  my $lower_d=$dseg_qstart;
  my $higher_d=$dseg_qend;
  if($dseg_qend<$lower_d){
    $lower_d=$dseg_qend;
    $higher_d=$dseg_qend;
  }

  # make sure D-seg is sandwiched
  if( ($v_average < $d_average) & ($d_average < $j_average) ) {
    # state is forward
    my $v_overlap= ${$self->{accVsegQend}}{$acc} - $lower_d;
    my $j_overlap= $higher_d - ${$self->{accJsegQstart}}{$acc};
    if($v_overlap>6){
      $answer=0;
    }
    if($j_overlap>6){
      $answer=0;
    }
  }elsif( ($v_average > $d_average) & ($d_average > $j_average)){
    # state is reversed
    my $v_overlap= $higher_d - ${$self->{accVsegQstart}}{$acc};
    my $j_overlap= ${$self->{accJsegQend}}{$acc} - $lower_d;
    if($v_overlap>6){
      $answer=0;
    }
    if($j_overlap>6){
      $answer=0;
    }
  }else{
    $answer=0;
  }

  return $answer;
}

sub batchBlastParseDsegClassifier {
  my($self,$db,$e,$outfile,$blast_type,$domain)=@_;
  unless($self->{ranVseg} && $self->{ranJseg}){
    print "V-seg and J-seg need to run first. Exiting...\n";
    exit;
  }
  my @lines=$self->getBlastLines($self->{filename},$db,$e,$blast_type);
 
  my %accessions=();
  my %acc_tophit=();

  for(my $x=0;$x<scalar(@lines);$x++){
    my($acc,$match,$pid,$alnlength,$mismatch,$gaps,$qstart,$qend,$mstart,$mend,$eval,$bit)=split(/\t/,$lines[$x]);
    my $hitname=$self->parse_hitname($match);

    if($self->isDsegSandwiched($acc,$qstart,$qend)){
      if(!(defined($acc_tophit{$acc}))){
        $acc_tophit{$acc} = $hitname;
        my $prob = 1;
        $accessions{$acc} = $hitname . " " . $alnlength . " " . $mismatch . " ";
        ${$self->{accDsegQstart}}{$acc}  = $qstart;
        ${$self->{accDsegQend}}{$acc}    = $qend;
      }elsif($acc_tophit{$acc} ne $hitname){
        my $prob = 1;
        if(defined($accessions{$acc})){
          my($best_match,$best_alnlength,$best_mismatch)=split(/ /,$accessions{$acc});
          $prob = $self->miscall_probability($best_alnlength,$alnlength,$best_mismatch,$mismatch);
          $prob = (int(1000 * $prob))/1000;
        }
        if($prob > 0.01){
          $accessions{$acc} .= $hitname . " " . $alnlength . " " . $mismatch . " ";
        }
      }
    }#else{
    #  print "D-seg sandwich fail!!!!\n";
    #}
  }

  my @keys=keys %accessions;
  open(OUT,">$outfile");
  for(my $k=0;$k<scalar(@keys);$k++){
    print OUT $keys[$k] . "\t" . $accessions{$keys[$k]} . "\n";
    ${$self->{$domain . "seg"}}{$keys[$k]}=$accessions{$keys[$k]};
  }
  print OUT "WRITEDONEFLAG" . "\t" . "\n";
  close(OUT);
  $self->{"ran" . $domain . "seg"}=1;
}

sub parse_hitname {
  my($self,$hitname)=@_;
  $hitname=~s/\*.*//;
  if($hitname=~m/IGH[GMEA]/){
    $hitname=~s/[0-9]*$//;
    $hitname=~s/P$//;
  }
  return $hitname;
}

sub miscall_probability{
  my($self,$sequence_length,$sequence_length2,$mutations1,$mutations2)=@_;
  my $length_diff=0;
  if($sequence_length2<$sequence_length){
    $length_diff=$sequence_length - $sequence_length2;
  }
  my $specific_mutations=$mutations2 - $mutations1 + $length_diff;
  my $total_mutations=$mutations2 + $specific_mutations;
  my $result=$self->nCk( ($sequence_length - $specific_mutations),($total_mutations - $specific_mutations) );
  my $result2=$self->nCk($sequence_length,$total_mutations);
  my $probability=($result/$result2);
  return $probability;
}

sub nCk {
  my($self,$n,$k)=@_;
  my $result=0; 
  #   n!
  # -----
  # k!(n-k)!
  my $nminusk=$n-$k;
  my @n_factorial=$self->factorial($n);
  my @nmink_factorial=$self->factorial($nminusk);

  my $numerator=1;
  my $denominator=1;
  for(my $x=1;$x<scalar(@n_factorial);$x++){
    if( $n_factorial[$x] && $nmink_factorial[$x] ){
      $n_factorial[$x]=0;
    }else{
      $numerator*=$x;
    }
  }
  for(my $x=$k;$x>1;$x--){
    $denominator *= $x;
  }
  $result=($numerator/$denominator);
  return $result;
}

sub factorial {
  my($self,$n)=@_;
  my @factorial=();
  while($n>0){
    $factorial[$n]=1;
    $n--;
  }
  return @factorial;
}

sub aascFvc2m {
  my($self)=@_;
  my $name = $self->{filename};
     $name =~ s/.[Ff][Nn]*[Aa][Ss]*[Tt]*[Aa]*$//;
  my $unique_file = $name . ".unique.fa";
  my $stockfile   = $name . ".stock";
  my $a2m_file    = $name . ".Vh-gs-Vk.a2m";
  my $c2m_file    = $name . ".Vh-gs-Vk.c2m";
  $self->makeAccessionsUnique();
  $self->writeSeqs($unique_file);
  $self->scFvAlign($unique_file,$stockfile);
  $self->stockholmToFasta($stockfile,$a2m_file);
  $self->cropToModel($a2m_file,$c2m_file);
  return $c2m_file;
}

sub aascFvc2mTCR {
  my($self)=@_;
  my $name = $self->{filename};
  #print "File is called $name prior to manipulation\n";
     $name =~ s/.[Ff][Nn]*[Aa][Ss]*[Tt]*[Aa]*$//;
  #print "File is called $name trying to find a file called $name.unique.fa\n";
  my $unique_file = $name . ".unique.fa";
  my $stockfile   = $name . ".stock";
  my $a2m_file    = $name . ".Vh-gs-Vk.a2m";
  my $c2m_file    = $name . ".Vh-gs-Vk.c2m";
  $self->makeAccessionsUnique();
  $self->writeSeqs($unique_file);
  $self->scFvAlignTCR($unique_file,$stockfile);
  #`rm $unique_file`;
  $self->stockholmToFasta($stockfile,$a2m_file);
  #`rm $stockfile`;
  $self->cropToModel($a2m_file,$c2m_file);
  return $c2m_file;
}


sub cropToModel {
  my($self,$a2m,$c2m)=@_;

  open(OUT,">$c2m");
  my $seqname="";
  my $seqseq="";

  my $x=-1;
  open MSA, $a2m;
  while (<MSA>) {
   chomp;
   if (/^>/) {
     my $tempname = $_;

     if($seqname ne ""){
       print OUT $seqname . "\n";
       $seqseq=~s/^[\.a-z]*//;
       $seqseq=~s/[\.a-z]*$//;
       print OUT $seqseq  . "\n";
       $seqseq="";
     }

     $seqname=$tempname;
     $x++;
   } else{
     my $tempseq = $_;
     $seqseq .= $tempseq;
   }
  }
  close(MSA);
  $seqseq=~s/^[\.a-z]*//;
  $seqseq=~s/[\.a-z]*$//;
  print OUT $seqname . "\n";
  print OUT $seqseq  . "\n";
  close(OUT);
}

sub getAccession2seqidHash {
  my($self,$hash)=@_;
  for(my $n=0;$n<$self->{nseqs};$n++){
    $$hash{$self->getAccession($n)}=$n;
  }
}

sub getH3dna {
  my($self,$dnafile,$a2mfile)=@_;

  my %h3_hash=();

  my $dnafasta=VDJFasta->new();
    $dnafasta->loadSeqs($dnafile);
  my $a2mfasta=VDJFasta->new();
    $a2mfasta->loadSeqs($a2mfile);
  my %dnaAccSeqid=();
    $dnafasta->getAccession2seqidHash(\%dnaAccSeqid);

  #print "I got " . $dnafasta->getSeqCount() . " dnaseqs and " . $a2mfasta->getSeqCount() . " aaseqs\n";
  

    # go through each sequence in the a2m alignment (as frameshifts can cause multiple appearances
    # of same accessions.
  my $a2m_counts=$a2mfasta->getSeqCount();
  for(my $a2m_seqid=0;$a2m_seqid<$a2m_counts;$a2m_seqid++){
     my $acc = $a2mfasta->getAccession($a2m_seqid);
     my $dna_seqid = $dnaAccSeqid{$acc};
     my($accession,$orientation,$BeginLen,$h3len,$EndLen)=$a2mfasta->getH3CoordsFromA2M($a2m_seqid);

     #Working with 6F6~MISEQ:45:000000000-A2WE9:1:1101:14300:2356,1,43,7,35
     #Extracted ,,

     #print "Working with $accession,$orientation,$BeginLen,$h3len,$EndLen\n";
     my ($lvseg,$dnaH3,$jcseg) = $dnafasta->getH3fromDNA($dna_seqid,$orientation,$BeginLen,$h3len,$EndLen);
     #print "Extracted $lvseg,$dnaH3,$jcseg\n";
     unless($dnaH3 eq ""){
       $h3_hash{$acc}=$dnaH3;
     }
   }
  return %h3_hash;
}

sub deMultiplexPlateReads {			# Arnold Han's plates of clones: need to handle mids differently
  my($self)=@_;

  my $verbose=0;
  my %plates = ("GCAGA","1",
		"TCGAA","2",
		"AACAA","3",
		"GGTGC","4",
		"TTGGT","5",
		"CATTC","6",
		"ATTGG","7",
		"CGGTT","8",
		"ATCCT","9",
		"ATGTC","10",
		"TCACG","11",
		"AGACC","12",
		"CCCCA","13",
		"GCGCT","14",
		"TCCTT","15",
		"TATAT","16",
		"CGTAA","17",
		"AAGGT","18",
		"AGCTC","19",
		"CCTGC","20",
		"GTATC","21",
		"TATGA","22",
		"CACAC","23",
		"ACACT","24",
		"ACTAC","25",
		"GTTAC","26"

);
  my %rows  =  ("TAAGC","A",
		"TGCAC","B",
		"CTCAG","C",
		"GGAAT","D",
		"CGAGG","E",
		"AGGAG","F",
		"TGTTG","G",
		"CAACT","H");
  my %cols  =  ("TGAAC","1",
		"TCCTG","2",
		"TATAA","3",
		"ACAGG","4",
		"GCGGT","5",
		"TAAGT","6",
		"CTAGC","7",
		"ACGTC","8",
		"TAGCC","9",
		"CATTC","10",
		"GTTGG","11",
		"GTCTC","12");

  my %mid_counts=();
  my @seq2mid=();
  # Arnold plate tech: perform a stepwise classification of reads to be as efficient as possible
  for(my $s=0;$s<$self->{nseqs};$s++){
    my $this_mid = "unknown";
    #my $error    = "";
    # pattern is 5' NN[plate 5mer]NN[row 5mer]NNNNN[sequence ~250-310bp]NNN[col 5mer]NN 3'
    # 12345678901234567890
    # NN.....NN.....NNNNNN
    my $plate_seq=substr(${$self->{sequence}}[$s],2,5);
    if(defined($plates{$plate_seq})){
      my $row_seq=substr(${$self->{sequence}}[$s],9,5);
      if(defined($rows{$row_seq})){
        my $col_seq=substr(${$self->{sequence}}[$s],-7,5);
        if(defined($cols{$col_seq})){
          $this_mid = $plates{$plate_seq} . $rows{$row_seq} . $cols{$col_seq};
          if(defined($mid_counts{$this_mid})){
            $mid_counts{$this_mid}++;
          }else{
            $mid_counts{$this_mid}=1;
          }
        }else{
          if($verbose){
            print "\t$s\t\t\tcannot find col_seq - $plate_seq $row_seq $col_seq\n";
          }
        }
      }else{
        if($verbose){
          print "\t$s\t\tcannot find rowseq - $plate_seq - $row_seq - ?\n";
        }
      }
    }else{
      if($verbose){
        print "\t$s\tcannot find plateseq - $plate_seq - ? - ?\n";
      }
    }
    $seq2mid[$s]=$this_mid;
  }

  # prepare outfiles
  my $input_file_prefix = $self->{filename};
     $input_file_prefix =~ s/.fasta$//;
     $input_file_prefix =~ s/.fa$//;
     $input_file_prefix =~ s/.fna$//;

  # open all files for writing
  my @midnames=keys %mid_counts;
  my %outfile_handles=();
  my %outfiles=();

  for(my $n=0;$n<scalar(@midnames);$n++){
    $outfiles{$midnames[$n]}=$input_file_prefix . "-" . $midnames[$n] . ".fa";
    open($outfile_handles{$midnames[$n]},">" . $outfiles{$midnames[$n]} );
    $mid_counts{$midnames[$n]}=0;
  }
  open($outfile_handles{"unknown"},">$input_file_prefix-unknown.MID.fa");
  $mid_counts{"unknown"}=0;
  #push @midseqs,"unknown";
  push @midnames,"unknown";
  @midnames=sort(@midnames);

  # write all files out
  for(my $s=0;$s<$self->{nseqs};$s++){
    my $this_mid=$seq2mid[$s];
    if(!(defined fileno $outfile_handles{$this_mid})){
      print "No file for |$this_mid|\n";
    }elsif(defined($outfile_handles{$this_mid})){
      #print "An opportunity to write\n";
      print {$outfile_handles{$this_mid}} ${$self->{headers}}[$s] . "\n"; # problem line - closed filehandle error
      print {$outfile_handles{$this_mid}} ${$self->{sequence}}[$s] . "\n"; # problem line
      $mid_counts{$this_mid}++;
    }else{
      print "Unclear what is going on for |$this_mid|\n";
    }
  }

  #close all files for writing, and return counts
  for(my $n=0;$n<scalar(@midnames);$n++){
    close($outfile_handles{$midnames[$n]});
    my $percent = (int(100000 * ($mid_counts{$midnames[$n]} / $self->{nseqs})))/1000 ;
    print $midnames[$n] . "\t" . $mid_counts{$midnames[$n]} . "\t$percent%\n";
    #      13A5                  0                                %
  }
}

sub getH3fromDNA { 
  my ($self,$dna_seqid,$orientation,$BeginLen,$h3len,$EndLen)=@_;

  my $vlLength = 90;
  my $start=0;
  my $stop=0;
  my $aasequence_length = $BeginLen + $h3len + $EndLen;
  my $cdrh3_dna_length= 3 * $h3len; #($EndLen - $BeginLen);
  my $lvseg  = ""; # leader sequence and vseg: anything before cdr3
  my $h3_dna = "";
  my $jcseg  = ""; # anything after cdr3
  my $gsseg  = ""; # linker
  my $vlseg  = ""; # variable domain
  print "orientation $orientation, $BeginLen,$h3len,$EndLen\n"; 
  if($orientation>=0){   			#forward orientation
    $start = $orientation + ( 3 * $BeginLen);
    $stop  = $start + $cdrh3_dna_length; 
    $h3_dna=$self->getSubSequence($dna_seqid,$start,$stop);
    $lvseg =$self->getSubSequence($dna_seqid,0,$start);
    $jcseg =$self->getSubSequence($dna_seqid,$stop,($stop+30));
    $gsseg =$self->getSubSequence($dna_seqid,($stop+30),($stop+75));   
    $vlseg =$self->getSubSequence($dna_seqid,($stop+75),($stop+75+($vlLength*3))); 

    #print " monkey Initially I get $start,$stop,$h3_dna,$lvseg,$jcseg,$gsseg,$vlseg\n";

  }else{     					# reverse orientation
    my $reverse_seq=$self->getReverseStrand($dna_seqid);
    my $negative_offset = abs($orientation) - 1;
    $start = ( 3 * $BeginLen) + $negative_offset;
    $stop  = $start + $cdrh3_dna_length;

    # now we go from start to stop
    my @chars=split(/ */,$reverse_seq);
    for(my $c=$start;$c<$stop;$c++){
      $h3_dna.=$chars[$c];
    }
    #select the variable domain
    $lvseg =substr($reverse_seq,0,$start);
    # select the jsegment. should always be a fixed length beyond the stop!
    $jcseg =substr($reverse_seq,$stop,30);  # MONKEY 
    $gsseg =substr($reverse_seq,($stop+30),45); #$self->getSubSequence($dna_seqid,($stop+30),($stop+75));
    $vlseg =substr($reverse_seq,($stop+75),($vlLength*3)); #$self->getSubSequence($dna_seqid,($stop+75),($stop+75+($vlLength*3)));
  }
  # make sure this stretch equals what is observed in -d";" -f5
  my $h3=VDJFasta->new();
     $h3->addSeq("header",$h3_dna);
  my ($h3_header,$h3_translation)=$h3->dna2aa(0,0);
  my $qc_h3 = $self->getHeaderField($dna_seqid,4);

  #$jcseg="~~~" . $jcseg . "|||";

  my $type = $self->getHeaderField($dna_seqid,1);
  #   $type = "TRDV"; # monkey gamma
  #if($type =~ m/TRDV/){
  #  $qc_h3 = $self->getHeaderField($dna_seqid,5);
  #}
  #print "I am sanity checking $qc_h3 ne $h3_translation ($h3_dna)\n";

  if ($qc_h3 ne $h3_translation){
    return ("","","");
  }else{
    return ($lvseg,$h3_dna,$jcseg,$gsseg,$vlseg);
  }
}

sub getH3CoordsFromA2M {
  my($self,$seq)=@_;
  # length to ends, length of H3 
  # want do do the H3 curate correction here
  my $h3Begins = $self->getHMMCOLRange($seq,0,88);
  my $h3Seq    = $self->getHMMCOLRange($seq,88,106);
  my $h3Ends   = $self->getHMMCOLRange($seq,106,400);

  # if gamma, then do this instead: 218 233
  #my $type = $self->getHeaderField($seq,1);
  #   $type="TRDV"; # monkey gamma
  #if($type =~ m/TRDV/){
  #  $h3Begins = $self->getHMMCOLRange($seq,0,216);
  #  $h3Seq    = $self->getHMMCOLRange($seq,216,234);
  #  $h3Ends   = $self->getHMMCOLRange($seq,234,400);
  #  #print "I got $h3Begins $h3Seq $h3Ends\n";
  #}
 
  $h3Begins =~ s/[\.\-]//g;
  $h3Seq =~ s/[\.\-]//g;
  $h3Ends =~ s/[\.\-]//g;
  $h3Begins =~ s/.$//;
  $h3Ends =~ s/^.//;

  my $orientation=$self->getHeader($seq);
     $orientation=~s/;.*//;
     $orientation=~s/..*frame_//;
  my $accession=$self->getAccession($seq);

  return($accession,$orientation,(length($h3Begins)+2),(length($h3Seq)-4),(length($h3Ends)+2));
}


sub stockholmToFasta {
  my($self,$stockfile,$outfile)=@_;
  my %seqs = ();
  my $start=0;

  open(MSA,$stockfile);
  while(<MSA>){
    my $line=$_;
    chop($line);
    if($line =~ m/#/){
      $start=1;
    }
    if($start){
      if( !(($line =~ m/^#/) || ($line =~ m/^ *$/) || ($line =~ m/^\/\//)) ){
        my @fields = split(/  */,$line);
        if(exists($seqs{$fields[0]})){
          $seqs{$fields[0]} .= $fields[1];
        } else {
          $seqs{$fields[0]} = $fields[1];
        }
      }
    }
  }
  close(MSA);

  open(OUT,">$outfile");
  while ( my($key,$value) = each(%seqs)){
    print OUT ">$key\n";
    print OUT "$value\n";
  }
  close(OUT);
}

sub makeAccessionsUnique {
  my($self)=@_;
  my %accessions_already_seen=();
  
  for(my $s=0;$s<$self->{nseqs};$s++){
    ${$self->{headers}}[$s]=~s/ /_/g;
    if(defined($accessions_already_seen{${$self->{headers}}[$s]})){
      while(defined($accessions_already_seen{${$self->{headers}}[$s]})){
        ${$self->{headers}}[$s].= "." . int(rand(100000));
      }
    }
    $accessions_already_seen{${$self->{headers}}[$s]}=1;
  }
}

sub scFvAlignTCR {
  my($self,$seqfile,$outfile)=@_;
  my $cmd = $self->{hmmalign}
          . " --allcol --amino "
          . $self->{TCRVhVkHMM}
          . " $seqfile > $outfile";
  `$cmd`;
}

sub scFvAlign {
  my($self,$seqfile,$outfile)=@_;
  my $cmd = $self->{hmmalign}
          . " --allcol --amino "
          . $self->{VhVkHMM}
          . " $seqfile > $outfile";
  `$cmd`;
}

sub igScoreTCR {
  my($self,$evalue)=@_;

  # score all frames with hmm. add "-A 0" to store alignment of all hits
  my $cmd = $self->{hmmsearch}
          . " -E $evalue "
          . $self->{TCRVhVkHMM}
          . " " . $self->{filename}
          . " > " . $self->{filename}
          . ".$evalue.1e-05.score.txt";
  `$cmd`;

  # generate hmmscore hits
  my @scored_hits=();
  open(FILE,$self->{filename} . ".$evalue.1e-05.score.txt");
  my @lines=<FILE>;
  close(FILE);
  chomp(@lines);
  my $score_file=$self->{filename} . ".$evalue.1e-05.score.txt";
  #`rm $score_file`;

  my $recording=0;
  for(my $x=0;$x<scalar(@lines);$x++){
    if($lines[$x]=~m/^>>/){
      $lines[$x]=~s/^>>* *//;
      $lines[$x]=~s/  *$//;
      push @scored_hits,$lines[$x];
    }
  }
  return @scored_hits;
}

sub igScore {
  my($self,$evalue)=@_;

  # score all frames with hmm. add "-A 0" to store alignment of all hits
  my $cmd = $self->{hmmsearch}
          . " -E $evalue "
          . $self->{VhVkHMM}
          . " " . $self->{filename}
          . " > " . $self->{filename}
          . ".$evalue.1e-10.score.txt";
  `$cmd`;

  # generate hmmscore hits
  my @scored_hits=();
  open(FILE,$self->{filename} . ".$evalue.1e-10.score.txt");
  my @lines=<FILE>;
  close(FILE);
  chomp(@lines);
  my $recording=0;
  for(my $x=0;$x<scalar(@lines);$x++){
    if($lines[$x]=~m/^>>/){
      $lines[$x]=~s/^>>* *//;
      $lines[$x]=~s/  *$//;
      push @scored_hits,$lines[$x];
    }
  }
  return @scored_hits;
}

sub addHeaderAnnotation {
  my($self,$annotation_file)=@_;

  # load file (accession	annotation)
  my %acc2cdr=();
  open(FILE,$annotation_file);
  my @lines=<FILE>;
  close(FILE);
  chomp(@lines);
  for(my $i=0;$i<scalar(@lines);$i++){
    my @fields=split(/\t/,$lines[$i]);
    if(defined($fields[1])){
      $fields[1]=~s/ *$//;
    }else{
      $fields[1]="";
    }
    $fields[0]=~s/^> *//;
    $fields[0]=~s/ *//;
    $acc2cdr{$fields[0]}=$fields[1];
  }

  # apply annotations
  for(my $n=0;$n<$self->{nseqs};$n++){
    ${$self->{headers}}[$n] .= ";"; 
    if(defined($acc2cdr{$self->getAccession($n)})){
      ${$self->{headers}}[$n] .= $acc2cdr{$self->getAccession($n)};
    }
  }
}

sub getBlastLines {
  my($self,$seqfile,$blastdb,$eval,$blast_type)=@_;
  # modification suggested by Chris Van Belle
  my $command=$self->{blast} . " -task blastn-short -query $seqfile -db $blastdb -outfmt 6 -evalue $eval";
  my @lines=`$command`;
  return @lines;
}

sub getHeader {
  my($self,$c)=@_;
  return ${$self->{headers}}[$c];
}

sub getAccession {
  my($self,$c)=@_;
  my $header=$self->getHeader($c);
  $header=~s/ .*//;
  $header=~s/;.*//;
  $header=~s/^>//;
  $header=~s/_frame_[0123-]* *$//;
  return $header;
}

sub loadSeqs {
  my ($self,$file)=@_;
  if(-s $file > 10){
    $self->{filename}=$file;
  } else {
    print "File $file does not exist.\n";
    return 0;
  }

  # load seqs into filename, headers and sequence
  my $x=-1;
  open FASTA, $self->{filename};
  while (<FASTA>) {
    chomp;
    if (/^>/) {
      push @{$self->{headers}},$_;
      $x++;
    } else {
      ${$self->{sequence}}[$x] .= $_;
    }
  }
  $x++;
  $self->{nseqs}=$x;
}

sub addSeq {
  my($self,$header,$sequence)=@_;
  push @{$self->{headers}},$header;
  push @{$self->{sequence}},$sequence;
}

sub getSeqLen {
  my($self,$c)=@_;
  my $seq=${$self->{sequence}}[$c];
  my $count=length($seq);
  return $count;
}

sub printSeqs {
  my($self)=@_;
  for(my $s=0;$s<$self->{nseqs};$s++){
    $self->printSeq($s);
  }
}

sub printSeqRange {
  my($self,$start,$stop)=@_;
  for(my $s=$start;$s<$stop;$s++){
    $self->printSeq($s);
  }
}

sub printSeq {
  my($self,$s)=@_;
  print ${$self->{headers}}[$s] . "\n";
  print ${$self->{sequence}}[$s] . "\n";
}

sub getCDRHashFromHeaders {
  my($self,$cdr3)=@_;
  # assumes the headers have been encoded with H3 in field 5
  my $cdr3_field=4;
  if($cdr3 eq "L3"){
    $cdr3_field=5;
  }
  print "Fields is $cdr3_field\n";
  my %cdr_hash=();

  for(my $s=0;$s<$self->{nseqs};$s++){
    my @fields=split(/;/,${$self->{headers}}[$s]);
    if(defined($fields[$cdr3_field])){
      if(length($fields[$cdr3_field]) > 0){
        if(defined($cdr_hash{$fields[$cdr3_field]})){
          $cdr_hash{$fields[$cdr3_field]}.="," . $s;
        }else{
          $cdr_hash{$fields[$cdr3_field]} = $s;
        }
      }
    }
  }
  return %cdr_hash;
}

sub printSeqSubsetbyList {
  my($self,$accession_list,$outfile)=@_;

  my %selected_accessions=();
  my @lines=@$accession_list;

  open(OUTFILE,">$outfile");

  for(my $x=0;$x<scalar(@lines);$x++){
    my @data=split(/\t/,$lines[$x]);
    $selected_accessions{$data[0]}=1;
  } 
 
  for(my $s=0;$s<$self->{nseqs};$s++){
    my $acc=${$self->{headers}}[$s];
    $acc=~s/ .*//;
    $acc=~s/^>//;
    if($selected_accessions{$acc}){
      print OUTFILE ${$self->{headers}}[$s] . "\n";
      print OUTFILE ${$self->{sequence}}[$s] . "\n";
    }
  }
  print OUTFILE "";
  close(OUTFILE);
}

sub getSeq{
  my($self,$seq)=@_;
  return (${$self->{headers}}[$seq],${$self->{sequence}}[$seq]);
}

sub getSeqCount{
  my($self)=@_;
  return $self->{nseqs};
}

sub writeSeq {
  my($self,$seq,$file)=@_;
  open(FILE,">$file");
  print FILE ${$self->{headers}}[$seq]  . "\n";
  print FILE ${$self->{sequence}}[$seq] . "\n";
  close(FILE);
  return $file;
}

sub writeSeqs {
  my($self,$file)=@_;
  open(FILE,">$file");
  for(my $s=0;$s<$self->{nseqs};$s++){
    print FILE ${$self->{headers}}[$s]  . "\n";
    print FILE ${$self->{sequence}}[$s] . "\n";
  }
  close(FILE);
}

sub writeSeqRange {
  my($self,$file,$start,$stop)=@_;
  open(FILE,">$file");
  if($stop>$self->{nseqs}){
    $stop=$self->{nseqs};
  }
  for(my $s=$start;$s<$stop;$s++){
    print FILE ${$self->{headers}}[$s]  . "\n";
    print FILE ${$self->{sequence}}[$s] . "\n";
  }
  close(FILE);
}

sub getMutatedSeq {
  my($self,$seq,$nmutations,$trim5prime,$trim3prime)=@_;
  my $mutseq=${$self->{sequence}}[$seq];

  # trime 5 prime and 3 prime
  if($trim5prime){
    $mutseq=substr($mutseq,$trim5prime);
  }
  if($trim3prime){
    $mutseq=substr($mutseq,0,(0 - $trim3prime));
  }

  # perform mutations
  my @chars=('C','A','T','G');
  my @res=split(/ */,$mutseq);
  my $mut_down=$nmutations;
  while($mut_down>0){
    my $position=int(rand(scalar(@res)));
    my $new=$chars[int(rand(4))];
    while($new eq uc($res[$position])){
      $new=$chars[int(rand(4))];
    }
    $res[$position]=$new;
    $mut_down--;
  }
  $mutseq=join('',@res);

  return $mutseq;
}

sub writeMutatedSeq {
  my($self,$seq,$file,$nmutations,$trim5prime,$trim3prime)=@_;

  my $mutseq=$self->getMutatedSeq($seq,$nmutations,$trim5prime,$trim3prime);
  
  open(FILE,">$file");
  print FILE ${$self->{headers}}[$seq]  . " with $nmutations mutations\n";
  print FILE $mutseq . "\n";
  close(FILE);
  return $file;
}



sub hmmSearch {
  my($self,$seqfile,$hmm,$eval)=@_;
  my $hmmsearch=$self->{hmmsearch};
  my @results=`$hmmsearch -E $eval $hmm $seqfile`;
  my @frames=();
  my $print=1;
  for(my $x=0;$x<scalar(@results);$x++){
    if($results[$x]=~m/^frame/){
      if($results[$x]=~m/domain/){
        my $line=$results[$x];
        $line=~s/^frame//;
        $line=~s/: .*//;
        chomp($line);
        push @frames,$line;
      }
    }
  }
  return @frames;
}

sub getPercentGc {
  my($self,$c)=@_;
  my ($header,$oligo)=$self->getSeq($c);
  my @chars=split(/ */,$oligo);
  my $gc=0;
  for(my $g=0;$g<scalar(@chars);$g++){
    if($chars[$g]=~m/[gcGC]/){
      $gc++;
    }
  }
  my $percent_gc=0;
  if(scalar(@chars)>0){
    $percent_gc=((  int(1000 * ($gc/scalar(@chars))) )/10);
  }
  return $percent_gc;
}

sub rounded {
  my ($self,$value)=@_;
  my $rounded=((  int(10 * $value) )/10);
  return $rounded;
}

sub getReverseStrand {
  my($self,$c)=@_;

  my $seq=uc($self->getSequence($c)); 
  my @nucs=split(/ */,$seq);
  my $len=scalar(@nucs);
  my $reverse="";
  for(my $x=($len-1);$x>=0;$x--){
    if($nucs[$x] eq "T"){
      $reverse.="A";
    }elsif($nucs[$x] eq "A"){
      $reverse.="T";
    }elsif($nucs[$x] eq "G"){
      $reverse.="C";
    }elsif($nucs[$x] eq "C"){
      $reverse.="G";
    }else{
      $reverse.="X";
    }
  }
  return $reverse;
}

sub getSequence {
  my($self,$seq)=@_;
  return ${$self->{sequence}}[$seq];
}

sub setSequence {
  my($self,$c,$sequence)=@_;
  return ${$self->{sequence}}[$c]=$sequence;
}

sub codon2aa {
  my($codon) = @_;

  if ( $codon =~ /^TC/i ) { return 'S' } # Serine
  elsif ( $codon =~ /TT[CT]/i ) { return 'F' } # Phenylalanine
  elsif ( $codon =~ /TT[AG]/i ) { return 'L' } # Leucine
  elsif ( $codon =~ /TA[CT]/i ) { return 'Y' } # Tyrosine
  elsif ( $codon =~ /TA[AG]/i ) { return 'X' } # Stop
  elsif ( $codon =~ /TG[CT]/i ) { return 'C' } # Cysteine
  elsif ( $codon =~ /TGA/i ) { return 'X' } # Stop
  elsif ( $codon =~ /TGG/i ) { return 'W' } # Tryptophan
  elsif ( $codon =~ /^CT/i ) { return 'L' } # Leucine
  elsif ( $codon =~ /^CC/i ) { return 'P' } # Proline
  elsif ( $codon =~ /CA[CT]/i ) { return 'H' } # Histidine
  elsif ( $codon =~ /CA[AG]/i ) { return 'Q' } # Glutamine
  elsif ( $codon =~ /^CG/i ) { return 'R' } # Arginine
  elsif ( $codon =~ /AT[ACT]/i ) { return 'I' } # Isoleucine
  elsif ( $codon =~ /ATG/i ) { return 'M' } # Methionine
  elsif ( $codon =~ /^AC/i ) { return 'T' } # Threonine
  elsif ( $codon =~ /AA[CT]/i ) { return 'N' } # Asparagine
  elsif ( $codon =~ /AA[AG]/i ) { return 'K' } # Lysine
  elsif ( $codon =~ /AG[CT]/i ) { return 'S' } # Serine
  elsif ( $codon =~ /AG[AG]/i ) { return 'R' } # Arginine
  elsif ( $codon =~ /^GT/i ) { return 'V' } # Valine
  elsif ( $codon =~ /^GC/i ) { return 'A' } # Alanine
  elsif ( $codon =~ /GA[CT]/i ) { return 'D' } # Aspartic Acid
  elsif ( $codon =~ /GA[AG]/i ) { return 'E' } # Glutamic Acid
  elsif ( $codon =~ /^GG/i ) { return 'G' } # Glycine
  elsif ( $codon =~ m/N/ ) { return 'X' }   # N - unknown character
  else { return "X"; } # bad codon
}

sub dna2aa {
  my($self,$seq,$frame)=@_;

  # header
  my $header=$self->getHeader($seq);
     $header=~s/ .*//;
     $header.="_frame_$frame";

  # frame options: 
  my @nucs=();
  my $startframe=$frame;
  if($frame>=0){
    @nucs=split(/ */,$self->getSequence($seq));
  }else{
    @nucs=split(/ */,$self->getReverseStrand($seq));
    $startframe=-1 - $frame;
  }

  # get translation
  my $translation="";
  for(my $n=$startframe;$n<scalar(@nucs);$n+=3){
    unless(defined($nucs[($n+1)])){
      $nucs[($n+1)]="N";
    }
    unless(defined($nucs[($n+2)])){
      $nucs[($n+2)]="N";
    }
    my $codon=$nucs[$n] . $nucs[($n+1)] . $nucs[($n+2)];
    $translation.=codon2aa($codon);
  }
  return($header,$translation);
}

sub translateAllFramesToFile {
  my($self,$outfile)=@_;
  open(FILE,">$outfile");
  for(my $s=0;$s<$self->{nseqs};$s++){ 
    for(my $f=-3;$f<3;$f++){
      my($header,$seq)=$self->dna2aa($s,$f);
      print FILE $header .  "\n";
      print FILE $seq . "\n";  
    }
  }
  close(FILE);  
}

sub restackRange {
  my($self,$range_start,$range_stop)=@_;
  # restack the residues within this range
  # n_right_stack_residues: the number of residues to stack to the end of the range
  # all others are stacked from left to right

  # first determine the longest segment in the range
  my $longest=0;
  for(my $n=0;$n<$self->{nseqs};$n++){
    my $segment=$self->getHMMCOLRange($n,$range_start,$range_stop);
       $segment=~s/\.*//g;
       $segment=~s/^[A-Z-]//;
       $segment=~s/[A-Z-]$//;
    if(length($segment)>$longest){
      $longest=length($segment);
    }
  }
  
  # next proceed through all sequences, restacking the range and filling in the extra
  # space with enough dots to fit the $longest sequence
  for(my $n=0;$n<$self->{nseqs};$n++){
    my $segment_before=$self->getHMMCOLRange($n,0,$range_start);
    my $segment_after =$self->getHMMCOLRange($n,$range_stop,length($self->getSeq($n)));
       $segment_before=~s/[a-z\.]*$//;
       $segment_after=~s/^[a-z\.]*//;

    # obtain segment
    my $segment=$self->getHMMCOLRange($n,$range_start,$range_stop);
       $segment=~s/\.*//g;
       $segment=~s/^[A-Z-]//; # remove boundary position, as it is represented in segment_before
       $segment=~s/[A-Z-]$//; # remove boundary position, as it is represented in segment_after
    # get hmmcol count
    my $hmmcols=$segment;
       $hmmcols=~s/[a-z]//g;
    my $hmmcol_count=length($hmmcols);
    # split in half
    my $halfway = int ( (length($segment) + 1)/2 ); #half way, round up
    my $segment_first_half=substr($segment,0,$halfway);
    my $segment_second_half=substr($segment,$halfway); # +1 I think
    # create middle gap
    my $middle_gap="";
    my $length_difference=$longest - length($segment);
    for(my $x=0;$x<$length_difference;$x++){
      $middle_gap.=".";
    }
    # create the new string
    my $structurally_correct_loop=lc($segment_first_half . $middle_gap . $segment_second_half);
    # reassign the HMM columns
       $structurally_correct_loop=~s/\-/./g;
    my @chars=split(/ */,$structurally_correct_loop);
    my $hmmcol_halfway=int ($hmmcol_count/2);
    for(my $p=(scalar(@chars)-1);(($hmmcol_halfway>0)&&($p>=0));$p--){
      $chars[$p]=uc($chars[$p]);
      $chars[$p]=~s/\./-/;
      $hmmcol_halfway--;
      $hmmcol_count--;
    }
    for(my $p=0;(($hmmcol_count>0)&&($p<scalar(@chars)));$p++){
      $chars[$p]=uc($chars[$p]);
      $chars[$p]=~s/\./-/;
      $hmmcol_count--;
    }
    $structurally_correct_loop="";
    for(my $x=0;$x<scalar(@chars);$x++){
      $structurally_correct_loop.=$chars[$x];
    }
    #print $segment_before . "\t" .  $structurally_correct_loop . "\t" . $segment_after . "\n";
    $self->setSequence($n,($segment_before . $structurally_correct_loop . $segment_after)); 
  }
}

sub getHMMCOLRange{
  my($self,$s,$startcol,$stopcol)=@_;
  my $sequence=$self->getSeq($s);
  my $subseq="";
  my @residues=split(/ */,$sequence);
  my $current_hmmcol=0;
  for(my $x=0;( ($x<scalar(@residues)) && ($current_hmmcol<=$stopcol));$x++){
    if( ($current_hmmcol >= $startcol) && ($current_hmmcol <= $stopcol) ){
      $subseq.=$residues[$x];
    }
    if($residues[$x]=~m/[A-Z-]/){
      $current_hmmcol++;
    }
  }
  return $subseq;
}

sub scoreMotif {
  my($self,$seq,$motif)=@_;
  # a sequence "TAVVYC" and a motif array "[ATY]","[CV]","[MTH]"
  $seq=~s/[a-z]//g;
  # next score states
  my @residues=split(/ */,$seq);

  my $score=0;
  for(my $m=0;$m<scalar(@$motif);$m++){
    if(defined($residues[$m])){
      my $position_motif=$$motif[$m];
      if($residues[$m]=~m/$position_motif/){
        $score++;
      }
    }
  }
  return $score;
}

sub qcH3TCR {
  my($self,$outfile)=@_;
  my $fw3_start=81;
  my $fw3_stop=91;

  my $fw4_start=104;
  my $fw4_stop=114;

  my $cdr3_start=91;
  my $cdr3_stop=104;
  my @VLfw4=("[FV]","G","[ADENPQSKT]","[EG]","[MSTI]","[QWRYK]","[LV]","[IEFLST]","[IV]","[QELTV]");
  my @VLfw3=("[AEKLQSGYVR]","[KLPQSET]","[EGNRS]","[EDHQ]","[AMSTE]","[ASG]","[FLMVSTK]","Y","[FLY]","C");

  # FGKGTQLIVEG
  # FGKGTRVTVEG
  # FGKGTYLEVQG
  # FGTGIKLFVEG

  #APSERDEGSYYC
  #APSERDEGSYYC
  #APSERDEGSYYC
  #PVRTEDSATYYC
  #PVRTEDSATYYC
  #ALQLEDSAKYFC

  open(OUT,">$outfile");
  for(my $n=0;$n<$self->{nseqs};$n++){
    my $fw3_subseq=$self->getHMMCOLRange($n,$fw3_start,$fw3_stop);
       $fw3_subseq=~s/[a-z\.]//g;
       $fw3_subseq=uc($fw3_subseq);
    my $fw4_subseq=$self->getHMMCOLRange($n,$fw4_start,$fw4_stop);
       $fw4_subseq=~s/[a-z\.]//g;
       $fw4_subseq=uc($fw4_subseq);
    my $cdr3_subseq=$self->getHMMCOLRange($n,($cdr3_start-1),$cdr3_stop);
       $cdr3_subseq=~s/[\.\-]//g;
       $cdr3_subseq=uc($cdr3_subseq);
    my $fw3_score = $self->scoreMotif($fw3_subseq,\@VLfw3);
    my $fw4_score = $self->scoreMotif($fw4_subseq,\@VLfw4);
    #print $fw3_subseq . "\t" . $cdr3_subseq . "\t" . $fw4_subseq . "\t" . $fw3_score . "\t" . $fw4_score . "\n";
    #print "\tIn qcH3TCR, received motif scores $fw3_score and $fw4_score for $fw3_subseq and $fw4_subseq...\n";

    if($fw3_score>5){
      if($fw4_score>5){
         print OUT $self->getAccession($n) . "\t" . $cdr3_subseq . "\n";
       }
     }
   }
  close(OUT);
}

sub qcH3 {
  my($self,$outfile)=@_;
  my $fw3_start=85;
  my $fw3_stop=94;
  my $fw4_start=102;
  my $fw4_stop=112;
  my $cdr3_start=94;
  my $cdr3_stop=102;
  my @VHfw4=("W","[GS]","[QPR]","G","[TASM]","[LTM]","[VLIA]","[TAINS]","[VAI]","[SAP]","[SAP]");
  my @VHfw3=("[RKTDQ]","[ASTVP]","[EDAS]","D","[TSA]","[AG]","[VTILF]","Y","[YF]","C");

  open(OUT,">$outfile");

  for(my $n=0;$n<$self->{nseqs};$n++){
    my $fw3_subseq=$self->getHMMCOLRange($n,$fw3_start,$fw3_stop);
       $fw3_subseq=~s/[a-z\.]//g;
       $fw3_subseq=uc($fw3_subseq);
    my $fw4_subseq=$self->getHMMCOLRange($n,$fw4_start,$fw4_stop);
       $fw4_subseq=~s/[a-z\.]//g;
       $fw4_subseq=uc($fw4_subseq);
    my $cdr3_subseq=$self->getHMMCOLRange($n,$cdr3_start,$cdr3_stop);
       $cdr3_subseq=~s/[\.\-]//g;
       $cdr3_subseq=uc($cdr3_subseq);
    my $fw3_score = $self->scoreMotif($fw3_subseq,\@VHfw3);
    my $fw4_score = $self->scoreMotif($fw4_subseq,\@VHfw4);
    if($fw3_score>6){
      if($fw4_score>6){
         print OUT $self->getAccession($n) . "\t" . $cdr3_subseq . "\n";
       }
     }
   }
   close(OUT);
}

sub qcL3TCR {
    my($self,$outfile)=@_;
    my $fw3_start=209;
    my $fw3_stop=219;

    my $fw4_start=232;
    my $fw4_stop=242;
    my $cdr3_start=219;
    my $cdr3_stop=232;

#TSTLTIHNVEKQDIATYYC ALWETVEL....GKKI.kV FGPGTKLII--
#-AVLKILAPSERDEGPYYC ACDALTGDt.lyTDKL..I FGKGTRVTVEP
#-AVLKILAPSERDEGSYYC ACDTITGAw..dTRQM..F FGTGIKLFVEP
#TSTLTIHNVEKQDIATYYC ALWETVEL....GKKI.kV FGPGTKLII--
#TSTLTIHNVEKQDIATYYC ALWEVHKE....LGKKikV FGPGTKLII--
#TSTLTIHNVEKQDIATYYC ALWEVHKE....LGKKikV FGPGTKLII--
#TSTLTIHNVEKQDIATYYC ALWETVEL....GKKI.kV FGPGTKLII--
#-AVLKILAPSERDEGSFYC ACDPLGLGdtpvTDKL..I FGKGTRVTVEP
#NLRMILRNLIENDSGVYYC ATWGHR--....-DQX..L FGSGTTLVVT-
#TSTLTIHNVEKQDIATYYC ALWEVHKE....LGKKikV FGPGTKLII--
#TSTLTIHNVEKQDIATYYC ALWETVEL....GKKI.kV FGPGTKLII--
#         SKQ I PF                         P    F E
#         E R E                             
#	  I N

#-AVLKILAPSERDEGSYYC ACDTITGAwdTRQMF     FGTGIKLFVEP
#NLRMILRNLIENDSGVYYC ATWGHR--..-DQXL     FGSGTTLVVT-

    my @VHfw3=("[LHQVRSEI]","[MEILHPTWK]","[EGSTQRN]","D","[ASTIE]","[ATG]","[ISELTVP]","[YF]","[FLIY]","C");
    my @VHfw4=("[FW]","[G]","[LADKQSTHP]","G","[TI]","[KLQIRST]","[LV]","[ILQSTVF]","[IV]","[EIKLNQRST]");

    open(OUT,">$outfile");

    for(my $n=0;$n<$self->{nseqs};$n++){
	my $fw3_subseq=$self->getHMMCOLRange($n,$fw3_start,$fw3_stop);
       $fw3_subseq=~s/[a-z\.]//g;
	$fw3_subseq=uc($fw3_subseq);
	my $fw4_subseq=$self->getHMMCOLRange($n,$fw4_start,$fw4_stop);
       $fw4_subseq=~s/[a-z\.]//g;
	$fw4_subseq=uc($fw4_subseq);
	my $cdr3_subseq=$self->getHMMCOLRange($n,($cdr3_start-1),$cdr3_stop);
       $cdr3_subseq=~s/[\.\-]//g;
	$cdr3_subseq=uc($cdr3_subseq);
	my $fw3_score = $self->scoreMotif($fw3_subseq,\@VHfw3);
	my $fw4_score = $self->scoreMotif($fw4_subseq,\@VHfw4);
        #print "\tIn qcL3TCR, received motif scores $fw3_score and $fw4_score for $fw3_subseq and $fw4_subseq...\n";
	if($fw3_score>5){
	    if($fw4_score>5){
		print OUT $self->getAccession($n) . "\t" . $cdr3_subseq . "\n";
	    }
	}
    }
    close(OUT);
}
sub qcL3 {
  my($self,$outfile)=@_;
  my $fw3_start=207;
  my $fw3_stop=215;
  my $fw4_start=226;
  my $fw4_stop=237;
  my $cdr3_start=215;
  my $cdr3_stop=226;
  my @VLfw4=("[F]","[G]","[GQPT]","[G]","[T]","[KQR]","[LV]","[DET]","[IV]","[KL]");
  my @VLfw3=("[AEPST]","[DE]","[D]","[AEFILSTV]","[AGV]","[DILMSTV]","[Y]","[YFH]","[C]");

  open(OUT,">$outfile");
  for(my $n=0;$n<$self->{nseqs};$n++){
    my $fw3_subseq=$self->getHMMCOLRange($n,$fw3_start,$fw3_stop);
       $fw3_subseq=~s/[a-z\.]//g;
       $fw3_subseq=uc($fw3_subseq);
    my $fw4_subseq=$self->getHMMCOLRange($n,$fw4_start,$fw4_stop);
       $fw4_subseq=~s/[a-z\.]//g;
       $fw4_subseq=uc($fw4_subseq);
    my $cdr3_subseq=$self->getHMMCOLRange($n,$cdr3_start,$cdr3_stop);
       $cdr3_subseq=~s/[\.\-]//g;
       $cdr3_subseq=uc($cdr3_subseq);
    my $fw3_score = $self->scoreMotif($fw3_subseq,\@VLfw3);
    my $fw4_score = $self->scoreMotif($fw4_subseq,\@VLfw4);
    #print $fw3_subseq . "\t" . $cdr3_subseq . "\t" . $fw4_subseq . "\t" . $fw3_score . "\t" . $fw4_score . "\n";
    if($fw3_score>6){
      if($fw4_score>6){
         print OUT $self->getAccession($n) . "\t" . $cdr3_subseq . "\n";
       }
     }
   }
  close(OUT);
}

sub printDNAseqs {
  my($self)=@_;
  for(my $n=0;$n<$self->{nseqs};$n++){
    if($self->isDNA($n)){
      $self->printSeq($n);
    }
  }
}

sub printAAseqs {
  my($self)=@_;
  for(my $n=0;$n<$self->{nseqs};$n++){
    unless($self->isDNA($n)){
      $self->printSeq($n);
    }
  }
}

sub isDNA {
  my($self,$c)=@_;
  my $seq=uc($self->getSequence($c));
     $seq=~s/\.*//g;
     $seq=~s/\-*//g;
     $seq=~s/X//g;
  my $chars=length($seq);
     $seq=~s/[ACGTN]*//g;
  my $non_nuc=length($seq);
  my $non_nuc_fraction=$non_nuc/$chars;
  if($non_nuc_fraction<0.10){
    return 1;
  }else{
    return 0;
  }
}

sub getSubSequence {
  my($self,$seq,$start,$stop)=@_;

  if($start eq ""){
    return "";
  }
  if($stop eq ""){
    return "";
  }
  if($stop<$start){
    my $temp=$start;
    $start=$stop;
    $stop=$temp;
  }
  if($start<0){
    $start=0;
  }
  if($stop<0){
    $stop=0;
  }
  if($stop > length(${$self->{sequence}}[$seq])){
    $stop=length(${$self->{sequence}}[$seq]);
  }
  if( ($stop - $start) < 0){
    return "";
  }
  my $substr=substr(${$self->{sequence}}[$seq],$start,($stop - $start));
  return $substr;
}

sub getHeaderField {
  my($self,$seqid,$field)=@_;
  my $this_header = $self->getHeader($seqid);
  my @fields=split(/;/,$this_header);
  chomp(@fields);
  if(defined($fields[$field])){
    return $fields[$field];
  }else{
    return "";
  }
}

sub loadMIDs {
  my($self,$midfile)=@_;

  unless(-f $midfile){
    print "Error! No midfile $midfile was detected!\n";
    exit;
  }else{
    open(FILE,$midfile);
    my @lines=<FILE>;
    chomp(@lines);
    close(FILE);

    for(my $x=0;$x<scalar(@lines);$x++){
      my @fields=split(/\t/,$lines[$x]);
      unless(scalar(@fields) == 2){
        print "Error! Wrong number of fields on line $x in midfile $midfile: " . $lines[$x] . "\n";
        print "Format should be: midname<tab>midseq\n";
        exit;
      }else{
        my $midname=$fields[0];
        my $midseq =$fields[1];
        ${$self->{mids}}{$midseq}=$midname;
      }
    }
  }
}

1;
